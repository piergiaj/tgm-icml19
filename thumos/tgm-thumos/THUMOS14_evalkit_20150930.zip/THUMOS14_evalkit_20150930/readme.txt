THUMOS CHALLENGE 2014
http://crcv.ucf.edu/THUMOS14/index.html

-------------------------------------------------------------------

This directory contains Matlab functions designed for the evaluation
of temporal action detection in the THUMOS 2014 action detection challenge.

The data and the description of the THUMOS 2014 is available from
http://crcv.ucf.edu/THUMOS14/ In particular, the current package assumes
detection results in a format specified in the Evaluation Setup document
available from http://crcv.ucf.edu/THUMOS14/THUMOS14_Evaluation.pdf